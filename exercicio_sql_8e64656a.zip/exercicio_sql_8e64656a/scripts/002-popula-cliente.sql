INSERT INTO "clientes" ("nome", "cpf", "numero_compras") VALUES
  ('Allana Fidalgo Moreira',    '12345678900', 4),
  ('Benício Freire Sampaio',    '98765432100', 6),
  ('Orlando Pequeno Jesus',     '10293847560', 1),
  ('Olga Cascais Fortunato',    '01928374650', 2),
  ('Martinha Lima Zambujal',    '11992288445', 2),
  ('Anabela Baptista Soverosa', '22883377446', 6),
  ('Raul Arouca Pederneiras',   '11889922385', 1),
  ('Chico Buarque de Holanda',  '65719484743', 10),
  ('Lucca Santarém Branco',     '48769275911', 4),
  ('Patrícia Toste Prudente',   '19847457596', 3);
